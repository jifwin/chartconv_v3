sudo apt-get install python-pip pdf2svg python-opencv tesseract-ocr texlive-latex-base texlive-latex-extra texlive-luatex
sudo pip install colormath networkx

